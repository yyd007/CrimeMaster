use daiyDB;
-- 1. insert a new entry into Series, without error. 
CALL addAnatomy('USB Series','Adam Lambart','Michael Fassbander'); 
CALL addAnatomy('killyou','Adam Lambart','Michael Fassbander'); 
SELECT * FROM Anatomy WHERE ID = 'USB Series';
-- This command should return nothing because the ID is formatted wrongly.
SELECT * FROM Anatomy WHERE ID = 'killyou';


-- 2. find the number of disease associated with Agatha Christie
CALL num_author_books('Agatha Christie',@out_value);
SELECT @out_value; 
-- checking if the numbers match -- they do.
SELECT COUNT(*)
FROM Books INNER JOIN Writes wt ON (Books.BookTitle = wt.TargetID)
WHERE BookTitle LIKE '%The';

-- 3. find the name of the entity given its ID. In this case the name should be Violent Crimes.
-- SET @@local.net_read_timeout=3600;
CALL mapID(10, @out_name);
SELECT @out_name;
-- checking if the results match. 
SELECT CrimeName FROM Crime WHERE ID = 10;


-- 4. update author name to series author for books where they belong to series
-- This should return nothing, because originally there's no author called 'series author'
SELECT * FROM Series WHERE AuthorName = 'series author';
CALL up_update('series author');
-- This should return something
SELECT * FROM Series WHERE AuthorName = 'series author';


-- 5. delete Solves relations for specified crime name as source crime.
-- This number showing up form the sencond count should be smaller than the first one because something is deleted.

SELECT COUNT(*) FROM Solves;
CALL delete_solves('Violent Crimes');
SELECT COUNT(*) FROM Solves;

USE daiyDB;
SHOW TABLES;


