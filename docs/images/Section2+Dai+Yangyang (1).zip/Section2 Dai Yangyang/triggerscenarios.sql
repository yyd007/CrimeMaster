-- 1. 
-- This command should throw an error because the ID is formatted wrongly (doesn't end with 'SERIES')
INSERT INTO Series VALUES('A1','B1','C');
-- This command should work because the ID is formatted correctly
INSERT INTO Series VALUES('ABEF Series','B1','C');
-- showing the result of inserting Series, and the log table that keeps track of who and when the insertion is made.
SELECT * FROM Series WHERE ID='ABEF Series';
SELECT * FROM Entity_Insertion_Log;

-- 2. 
-- This command tries to insert a Character-CharacterRole relation into the table.
-- It should not work because the targetID is formatted wrongly.
INSERT INTO Plays
VALUES('2','3');
-- This command should work because both the sourceID and target ID are fomatted correctly.
INSERT INTO Plays
VALUES(8,8);
-- Showing the log table that keeps track of who and when the modification on relation was made.
SELECT * FROM Relation_Log;
-- Showing that if either the target or the source added to the relation did not exist, a new one is created.
SELECT * FROM Character WHERE ID = 8;
SELECT * FROM CharacterRole WHERE ID = 8;

-- 3.
-- Suppose we made some modification to the book. This command tries to update the entries where the book name is The Secret Adversary. 
-- It tries to change the crime id to another string, and change the book name to 'lkjhsad'
-- This command should not work (does not change the sourceID) because the new SourceID is formatted wrongly. 
UPDATE Commits
SET BookTitle = 'lkjhsad', SourceID = 'd'
WHERE SourceID=2;

-- Showing that the new SourceID did not make it into the table, but the book title has been changed.
-- And such update has been capture by the relation log. 
select * from Commits WHERE SourceID =11;
SELECT * FROM Relation_Log;

-- This command should work (does not change the sourceID) because the new SourceID is formatted wronly. 
UPDATE Commits
SET BookTitle = 'lkjhsad', SourceID = 11
WHERE SourceID=2;

-- Showing that this time the new SourceID did make it into the table, and the relation_type has been changed.
-- And such update has been capture by the relation log. 
select * from Commits WHERE SourceID =11;
SELECT * FROM Relation_Log;