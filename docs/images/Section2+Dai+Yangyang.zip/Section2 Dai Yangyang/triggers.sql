-- create a table to keep track of relation table changes
DROP TABLE IF EXISTS Relation_Log;
CREATE TABLE Relation_Log (
	SourceID VARCHAR(50),
	TargetID VARCHAR(50),
    Change_time DATETIME,
    User_name VARCHAR(50),
    update_type VARCHAR(50),
    PRIMARY KEY (Change_time, User_name)
);

-- create a table to keep track of insertion into entity tables
DROP TABLE IF EXISTS Entity_Insertion_Log;
CREATE TABLE Entity_Insertion_Log (
	ID VARCHAR (50),
    Change_time DATETIME,
    User_name VARCHAR(50),
    PRIMARY KEY (Change_time, User_name)
);

SELECT * FROM Series INNER JOIN Entity_Insertion_Log USING(ID);
-- Trigger 1: prevents insertion into Series if the SeriesName is not formatted correctly (i.e. ends with SERIES)
-- and keep logs of successfully inserted Series
DROP TRIGGER IF EXISTS Series_Format_Trigger;
DELIMITER |
CREATE Trigger Series_Format_Trigger
AFTER INSERT ON Series
FOR EACH ROW
BEGIN
	IF NOT (NEW.ID LIKE '%SERIES') THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Series Name is formatted wrongly.';
	ELSE 
		INSERT IGNORE INTO Entity_Insertion_Log VALUES (NEW.ID, NOW(),CURRENT_USER());
	END IF;
END; |
DELIMITER ;

-- trigger 2: when inserting new relation into Plays relation table, 
-- check if the CharacterID and CharacterRoleID are formatted correctly. If not, prevent the insertion from happening.
-- Otherwise, check if the two IDs are in the Character and CharacterRole table respectively. If not, add new entries to those tables.
-- If the insertion happens successfully, keep its log in Relation_Log
DROP TRIGGER IF EXISTS Character_CharacterRole_ExistsTrigger;
DELIMITER |
CREATE TRIGGER Character_CharacterRole_ExistsTrigger
AFTER INSERT ON Plays
FOR EACH ROW
	BEGIN		
		IF ISNUMERIC([NEW.SourceID]) = 1  AND ISNUMERIC([NEW.TargetID]) = 1 THEN
			INSERT IGNORE INTO Character(ID)	VALUES(NEW.SourceID);
			INSERT IGNORE INTO CharacterRole(ID) VALUES(NEW.TargetID);
			INSERT IGNORE INTO Relation_Log 
			VALUES(NEW.SourceID, New.TargetID, NOW(),CURRENT_USER(),'insertion');
		ELSE SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Either targetID or sourceID is formatted wrongly.';
		END IF;
END; |
DELIMITER ;


-- trigger3: when making update on Commits table, if the CrimeID and CharacterRoleID of the update are correctly formatted, then make the update.
-- Otherwise, use the old CrimeID/CharacterRoleID.
-- Also, register the update in the Relation_Log table.
DROP TRIGGER IF EXISTS CharacterRole_Crime_UpdateTrigger;
DELIMITER |
CREATE TRIGGER Character_CharacterRole_UpdateTrigger
BEFORE UPDATE ON Commits
FOR EACH ROW
	BEGIN
		IF ISNUMERIC([NEW.SourceID]) = 1  AND ISNUMERIC([NEW.TargetID]) = 1 THEN
			INSERT IGNORE INTO Relation_Log 
			VALUES(NEW.SourceID, New.TargetID, NOW(),CURRENT_USER(),'update');
		ELSE 
			SET NEW.SourceID = OLD.SourceID;
            SET NEW.TargetID = OLD.TargetID;
            INSERT IGNORE INTO Relation_Log 
            VALUES(NEW.SourceID, New.TargetID, NOW(),CURRENT_USER(),'update');
		END IF;
END; |
DELIMITER ;


