-- 1. add to Series with given inputs. It catches the errors caused by erroneously formatted series name
DROP PROCEDURE IF EXISTS addSeries;
DELIMITER |
CREATE PROCEDURE addSeries(	   
	IN series_name VARCHAR(100),	
	IN author_name VARCHAR(50),
    IN leading_charac VARCHAR(100))
BEGIN	
	DECLARE flag INT DEFAULT 0;
	DECLARE CONTINUE HANDLER	
		FOR SQLEXCEPTION
		SET flag = 1;    

	INSERT INTO Series
	VALUES(series_name, author_name, leading_charac);
END |

DELIMITER ;


-- 2. find the number of books associated with an author
DROP PROCEDURE IF EXISTS num_author_books;
DELIMITER |
CREATE PROCEDURE num_author_books(
	IN Author   VARCHAR (10),
    OUT num INT)
BEGIN
	SET num= (SELECT COUNT(*) FROM Writes wt
	INNER JOIN Books
	ON (Books.BookTitle = wt.TargetID)
	WHERE BookTitle LIKE '%The'));
    
END |

DELIMITER ;


-- 3. map IDs to names for any given ID
DROP PROCEDURE IF EXISTS mapID;
DELIMITER |
CREATE PROCEDURE mapID(
	IN kid   int,
    OUT entity_name VARCHAR (50) )
BEGIN

    DECLARE chname VARCHAR (50);
    DECLARE chrname VARCHAR (50);
    DECLARE crname VARCHAR (50);
	DECLARE flag INT DEFAULT 0;
    
    SET chname = (SELECT CharacterID FROM Characters WHERE ID = kid);
	SET chrname = (SELECT CharacterRoleID FROM CharacterRole WHERE ID = kid);
    SET crname = (SELECT CrimeID FROM Crime WHERE ID = kid);


	IF chname IS NOT NULL THEN SET entity_name = chname;
	ELSEIF chrname IS NOT NULL THEN SET entity_name = chrname;
	ELSEIF crname IS NOT NULL THEN SET entity_name = crname; 
	END IF;

END |

DELIMITER ;


-- 4. For all books, if they are in a series, update the author name to be series author
DROP PROCEDURE IF EXISTS up_update;
DELIMITER |
CREATE PROCEDURE up_update(
	IN series   VARCHAR (50))
BEGIN
	DECLARE flag INT DEFAULT 0;
    DECLARE selec_id VARCHAR(50);
	DECLARE temp CURSOR FOR 
    SELECT DISTINCT Series.SeriesName
    FROM Series INNER JOIN IsIn ii ON (Series.SeriesName = IsIn.SeriesName)
    WHERE SeriesName LIKE concat('Series%');
    
    DECLARE CONTINUE HANDLER	
	FOR NOT FOUND	
	SET flag = 1; 

	OPEN temp;
    REPEAT 
		FETCH temp INTO selec_id;
		UPDATE Series
			SET AuthorName = 'series author'
		WHERE ID = selec_id;
        UNTIL flag = 1
	END REPEAT;
	CLOSE temp;
    
END |

DELIMITER ;


-- 5. delete all solves relation for an input crime name source
DROP PROCEDURE IF EXISTS delete_solves;
DELIMITER |
CREATE PROCEDURE delete_solves(
	IN crime_name   VARCHAR (50))

BEGIN
	DECLARE flag INT DEFAULT 0;
    DECLARE s_id VARCHAR(50);
	DECLARE t_id VARCHAR(50);

	DECLARE temp CURSOR FOR 
    SELECT SourceID, TargetID 
    from Solves ss INNER JOIN Crime 
    ON (Crime.CrimeID = Solves.CrimeID) 
    WHERE CrimeName =crime_name;
    DECLARE CONTINUE HANDLER	
	FOR NOT FOUND	
	SET flag = 1;    

    OPEN temp;
    REPEAT 
		FETCH temp INTO s_id, t_id;
		DELETE FROM Solves
		WHERE SourceID = s_id AND TargetID = t_id;
        UNTIL flag = 1
	END REPEAT;
	CLOSE temp;
 
END |

DELIMITER ;